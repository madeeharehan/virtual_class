<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class UserController extends Controller
{
   	public function updateProfile(Request $request){

   	}
   	//public function updateProfilePhoto(Request $request){
   	//}
   	public function changePassword(Request $request){

   	}
}
