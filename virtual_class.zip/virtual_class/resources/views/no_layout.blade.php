<title>@yield('title') - {{config('app.name')}}</title>
