<script src="http://coderoj.com/style/lib/ckeditor/4.13.1/ckeditor.js"></script>
<textarea name="inputEditor"></textarea>

<script type="text/javascript">
	CKEDITOR.replace('inputEditor')
</script>