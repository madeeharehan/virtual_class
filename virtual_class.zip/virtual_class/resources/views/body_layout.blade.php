<title>@yield('title') - {{config('app.name')}}</title>
@yield('content')
