<input type="text" name="" value="{{Auth::user()->full_name}}">
