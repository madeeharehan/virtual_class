<style type="text/css">
	body{
		background-color: #ffffff;
		text-align: center;
	}
	.loadingTxt{
		color: #3EC79C;
		font-weight: bold;
		font-size: 30px;
		margin-top: -200px;
	}
</style>
<img src="{{asset('img/site/preload.gif')}}">
<div class="loadingTxt" id="loadingTxt">Loading 0%</div>
