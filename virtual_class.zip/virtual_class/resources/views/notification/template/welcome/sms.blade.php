Dear [[nickName]],
Congratulations for registration our classroom.
Login Id: [[login_id]]
Password: [[password]]

([[app_name]])