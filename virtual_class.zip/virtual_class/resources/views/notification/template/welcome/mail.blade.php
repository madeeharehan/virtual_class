Dear [[nickName]],<br/>Congratulations for registration our classroom.<br/>
Login Id: [[login_id]]<br/>
Password: [[password]]<br/>

([[app_name]])